using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Linq;

namespace IntroduccionRazor_ASPNET.Pages
{
    public class EstadisticasNumerosModel : PageModel
    {
        public int[] Numeros { get; set; } = new int[20];
        public int[] NumerosOrdenados { get; set; }
        public int Suma { get; set; }
        public double Promedio { get; set; }
        public string Moda { get; set; }
        public double Mediana { get; set; }

        public void OnGet()
        {
            // Generar n�meros aleatorios
            var random = new Random();
            for (int i = 0; i < Numeros.Length; i++)
            {
                Numeros[i] = random.Next(0, 101);
            }

            CalcularEstadisticas();
        }

        public IActionResult OnPostRegenerar()
        {
            // Regenerar n�meros aleatorios
            var random = new Random();
            for (int i = 0; i < Numeros.Length; i++)
            {
                Numeros[i] = random.Next(0, 101);
            }

            CalcularEstadisticas();
            return Page();
        }

        private void CalcularEstadisticas()
        {
            // Calcular suma usando ciclo for
            Suma = 0;
            for (int i = 0; i < Numeros.Length; i++)
            {
                Suma += Numeros[i];
            }

            // Calcular promedio
            Promedio = (double)Suma / Numeros.Length;

            // Ordenar arreglo (para mediana y moda)
            NumerosOrdenados = new int[Numeros.Length];
            Array.Copy(Numeros, NumerosOrdenados, Numeros.Length);

            // Ordenamiento con ciclo for
            for (int i = 0; i < NumerosOrdenados.Length - 1; i++)
            {
                for (int j = i + 1; j < NumerosOrdenados.Length; j++)
                {
                    if (NumerosOrdenados[i] > NumerosOrdenados[j])
                    {
                        int temp = NumerosOrdenados[i];
                        NumerosOrdenados[i] = NumerosOrdenados[j];
                        NumerosOrdenados[j] = temp;
                    }
                }
            }

            // Calcular moda
            int maxFrecuencia = 0;
            var modas = new System.Collections.Generic.List<int>();

            // Usando ciclo while para encontrar moda
            int k = 0;
            while (k < NumerosOrdenados.Length)
            {
                int numeroActual = NumerosOrdenados[k];
                int frecuencia = 1;

                // Contar frecuencia del n�mero actual
                int m = k + 1;
                while (m < NumerosOrdenados.Length && NumerosOrdenados[m] == numeroActual)
                {
                    frecuencia++;
                    m++;
                }

                // Actualizar moda si encontramos mayor frecuencia
                if (frecuencia > maxFrecuencia)
                {
                    maxFrecuencia = frecuencia;
                    modas.Clear();
                    modas.Add(numeroActual);
                }
                else if (frecuencia == maxFrecuencia && !modas.Contains(numeroActual))
                {
                    modas.Add(numeroActual);
                }

                k = m;
            }

            Moda = maxFrecuencia > 1 ? string.Join(" y ", modas) : "No hay moda (todos los n�meros son �nicos)";

            // Calcular mediana
            if (NumerosOrdenados.Length % 2 == 0)
            {
                // Para arreglos con cantidad par de elementos
                int medio1 = NumerosOrdenados.Length / 2 - 1;
                int medio2 = NumerosOrdenados.Length / 2;
                Mediana = (NumerosOrdenados[medio1] + NumerosOrdenados[medio2]) / 2.0;
            }
            else
            {
                // Para arreglos con cantidad impar de elementos
                Mediana = NumerosOrdenados[NumerosOrdenados.Length / 2];
            }
        }
    }
}