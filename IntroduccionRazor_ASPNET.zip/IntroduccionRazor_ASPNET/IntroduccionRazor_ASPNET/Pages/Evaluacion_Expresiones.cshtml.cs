using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace IntroduccionRazor_ASPNET.Pages
{
    public class Evaluacion_ExpresionesModel : PageModel
    {
        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        public string Resultado { get; set; }
        public string Pasos { get; set; }

        public class InputModel
        {
            [Required(ErrorMessage = "Este campo es obligatorio")]
            public double a { get; set; } = 2;

            [Required(ErrorMessage = "Este campo es obligatorio")]
            public double b { get; set; } = 1;

            [Required(ErrorMessage = "Este campo es obligatorio")]
            public double x { get; set; } = 3;

            [Required(ErrorMessage = "Este campo es obligatorio")]
            public double y { get; set; } = 2;

            [Required(ErrorMessage = "Este campo es obligatorio")]
            [Range(0, 20, ErrorMessage = "n debe estar entre 0 y 20")]
            public int n { get; set; } = 2;
        }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            (Resultado, Pasos) = CalcularExpansionBinomial(Input.a, Input.b, Input.x, Input.y, Input.n);
            return Page();
        }
        private (string resultado, string pasos) CalcularExpansionBinomial(double a, double b, double x, double y, int n)
        {
            StringBuilder pasosBuilder = new StringBuilder();
            double resultadoFinal = 0;

            // Paso 1: Mostrar la expresi�n original (aqu� s� podemos usar interpolaci�n)
            pasosBuilder.AppendLine($"<strong>Paso 1:</strong> Expresi�n original");
            pasosBuilder.AppendLine($"$$({a} \\cdot {x} + {b} \\cdot {y})^{n} = ({a * x} + {b * y})^{n} = ({a * x + b * y})^{n}$$");
            pasosBuilder.AppendLine();

            // Paso 2: Mostrar la f�rmula del binomio (versi�n corregida)
            pasosBuilder.AppendLine("<strong>Paso 2:</strong> Aplicando el teorema del binomio");
            pasosBuilder.AppendLine("$$\\sum_{m=0}^{" + n + "} \\binom{" + n + "}{m} (" + a + "\\cdot" + x + ")^{" + n + "-m} (" + b + "\\cdot" + y + ")^m$$");
            pasosBuilder.AppendLine();

            // Calcular cada t�rmino usando k como variable de bucle
            for (int k = 0; k <= n; k++)
            {
                long coeficiente = CalcularCoeficienteBinomial(n, k);
                double ax_pow = Math.Pow(a * x, n - k);
                double by_pow = Math.Pow(b * y, k);
                double termino = coeficiente * ax_pow * by_pow;
                resultadoFinal += termino;

                // Estos pasos s� pueden usar interpolaci�n
                pasosBuilder.AppendLine($"<strong>T�rmino k={k}:</strong>");
                pasosBuilder.AppendLine($"$$\\binom{{{n}}}{{{k}}} = \\frac{{{n}!}}{{{k}!({n}-{k})!}} = {coeficiente}$$");
                pasosBuilder.AppendLine($"$$({a}\\cdot{x})^{{{n}-{k}}} = {ax_pow}$$");
                pasosBuilder.AppendLine($"$$({b}\\cdot{y})^{{{k}}} = {by_pow}$$");
                pasosBuilder.AppendLine($"$$\\text{{T�rmino}} = {coeficiente} \\times {ax_pow} \\times {by_pow} = {termino}$$");
                pasosBuilder.AppendLine();
            }

            // Resultado final (interpolaci�n permitida)
            pasosBuilder.AppendLine($"<strong>Resultado final:</strong>");
            pasosBuilder.AppendLine($"$$\\text{{Suma de t�rminos}} = {resultadoFinal}$$");

            double resultadoDirecto = Math.Pow(a * x + b * y, n);
            pasosBuilder.AppendLine($"$$\\text{{Verificaci�n:}} ({a * x + b * y})^{n} = {resultadoDirecto}$$");

            return ($"({a}x + {b}y)^{n} = {resultadoFinal}", pasosBuilder.ToString());
        }

        private long CalcularCoeficienteBinomial(int n, int k)
        {
            if (k < 0 || k > n) return 0;
            if (k == 0 || k == n) return 1;

            k = Math.Min(k, n - k);
            long resultado = 1;

            for (int i = 1; i <= k; i++)
            {
                resultado *= (n - k + i);
                resultado /= i;
            }

            return resultado;
        }
    }
}
