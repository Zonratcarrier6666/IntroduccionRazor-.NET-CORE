using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IntroduccionRazor_ASPNET.Pages
{
    public class ArreglosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
