using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace IntroduccionRazor_ASPNET.Pages
{
    public class CifradoJulioCesarModel : PageModel
    {
        public class InputModel
        {
            [Required]
            public string Mensaje { get; set; }

            [Required]
            [Range(1, 25, ErrorMessage = "El desplazamiento debe estar entre 1 y 25")]
            public int Desplazamiento { get; set; }

            public bool Codificar { get; set; } = true;
        }

        [BindProperty]
        public InputModel Input { get; set; }

        public string Resultado { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            Resultado = Input.Codificar ?
                CodificarCesar(Input.Mensaje, Input.Desplazamiento) :
                DecodificarCesar(Input.Mensaje, Input.Desplazamiento);

            return Page();
        }

        private string CodificarCesar(string mensaje, int desplazamiento)
        {
            string resultado = "";
            foreach (char c in mensaje.ToUpper())
            {
                resultado += RotarLetra(c, desplazamiento);
            }
            return resultado;
        }

        private string DecodificarCesar(string mensaje, int desplazamiento)
        {
            return CodificarCesar(mensaje, 25 - (desplazamiento % 25));
        }

        private char RotarLetra(char letra, int desplazamiento)
        {
            // Primero verificamos si es una letra del alfabeto latino (sin W)
            if (!EsLetraValida(letra))
            {
                return letra; // Mantenemos caracteres que no est�n en el alfabeto
            }

            // Obtenemos la posici�n base (0-24)
            int posicion = ObtenerPosicion(letra);
            int nuevaPosicion = (posicion + desplazamiento) % 25;

            // Convertimos la nueva posici�n a letra
            return ObtenerLetra(nuevaPosicion);
        }

        private bool EsLetraValida(char letra)
        {
            switch (letra)
            {
                case 'A':
                case 'B':
                case 'C':
                case 'D':
                case 'E':
                case 'F':
                case 'G':
                case 'H':
                case 'I':
                case 'J':
                case 'K':
                case 'L':
                case 'M':
                case 'N':
                case 'O':
                case 'P':
                case 'Q':
                case 'R':
                case 'S':
                case 'T':
                case 'U':
                case 'V':
                case 'X':
                case 'Y':
                case 'Z':
                    return true;
                default:
                    return false;
            }
        }

        private int ObtenerPosicion(char letra)
        {
            switch (letra)
            {
                case 'A': return 0;
                case 'B': return 1;
                case 'C': return 2;
                case 'D': return 3;
                case 'E': return 4;
                case 'F': return 5;
                case 'G': return 6;
                case 'H': return 7;
                case 'I': return 8;
                case 'J': return 9;
                case 'K': return 10;
                case 'L': return 11;
                case 'M': return 12;
                case 'N': return 13;
                case 'O': return 14;
                case 'P': return 15;
                case 'Q': return 16;
                case 'R': return 17;
                case 'S': return 18;
                case 'T': return 19;
                case 'U': return 20;
                case 'V': return 21;
                case 'X': return 22;
                case 'Y': return 23;
                case 'Z': return 24;
                default: return -1;
            }
        }

        private char ObtenerLetra(int posicion)
        {
            // Aseguramos que la posici�n est� en el rango correcto (0-24)
            posicion = posicion % 25;
            if (posicion < 0) posicion += 25;

            switch (posicion)
            {
                case 0: return 'A';
                case 1: return 'B';
                case 2: return 'C';
                case 3: return 'D';
                case 4: return 'E';
                case 5: return 'F';
                case 6: return 'G';
                case 7: return 'H';
                case 8: return 'I';
                case 9: return 'J';
                case 10: return 'K';
                case 11: return 'L';
                case 12: return 'M';
                case 13: return 'N';
                case 14: return 'O';
                case 15: return 'P';
                case 16: return 'Q';
                case 17: return 'R';
                case 18: return 'S';
                case 19: return 'T';
                case 20: return 'U';
                case 21: return 'V';
                case 22: return 'X';
                case 23: return 'Y';
                case 24: return 'Z';
                default: return ' ';
            }
        }
    }
}