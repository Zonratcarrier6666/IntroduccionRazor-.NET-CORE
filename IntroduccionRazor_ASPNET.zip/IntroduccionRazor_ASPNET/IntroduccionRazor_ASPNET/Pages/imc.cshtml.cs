using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IntroduccionRazor_ASPNET.Pages
{
    public class imcModel : PageModel
    {
        [BindProperty]
        [Required(ErrorMessage = "El peso es requerido")]
        [Range(0.1, 300, ErrorMessage = "Peso debe ser entre 0.1 y 300 kg")]
        public double peso { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "La altura es requerida")]
        [Range(0.1, 3, ErrorMessage = "Altura debe ser entre 0.1 y 3 metros")]
        public double altura { get; set; }

        public double imc { get; set; }
        public string Clasificacion { get; set; }
        public string Recomendacion { get; set; }
        public string AlertClass { get; set; }

        public void OnGet()
        {
        }
        public void OnPost()
        {
            if (ModelState.IsValid)
            {
                imc = peso / (altura * altura);
                ClasificarIMC();
            }
        }
        private void ClasificarIMC()
        {
            if (imc < 18)
            {
                Clasificacion = "Peso bajo";
                Recomendacion = "Consulta a un nutricionista para un plan de aumento de peso saludable. Considera aumentar tu ingesta cal�rica con alimentos nutritivos.";
                AlertClass = "alert-warning";
            }
            else if (imc >= 18 && imc < 25)
            {
                Clasificacion = "Peso normal";
                Recomendacion = "�Excelente! Mant�n una dieta balanceada y ejercicio regular para conservar tu peso saludable.";
                AlertClass = "alert-success";
            }
            else if (imc >= 25 && imc < 27)
            {
                Clasificacion = "Sobrepeso";
                Recomendacion = "Controla tu alimentaci�n y aumenta tu actividad f�sica. Peque�os cambios pueden prevenir la obesidad.";
                AlertClass = "alert-info";
            }
            else if (imc >= 27 && imc < 30)
            {
                Clasificacion = "Obesidad grado I";
                Recomendacion = "Recomendamos consultar a un profesional de la salud. Reduce alimentos procesados y aumenta ejercicio aer�bico.";
                AlertClass = "alert-warning";
            }
            else if (imc >= 30 && imc < 40)
            {
                Clasificacion = "Obesidad grado II";
                Recomendacion = "Consulta urgente con m�dico y nutricionista. Necesitas un plan personalizado de alimentaci�n y ejercicio.";
                AlertClass = "alert-danger";
            }
            else
            {
                Clasificacion = "Obesidad grado III (Obesidad m�rbida)";
                Recomendacion = "Requiere atenci�n m�dica inmediata. Existen tratamientos multidisciplinarios que pueden ayudarte.";
                AlertClass = "alert-danger";
            }
        }
    }
}
