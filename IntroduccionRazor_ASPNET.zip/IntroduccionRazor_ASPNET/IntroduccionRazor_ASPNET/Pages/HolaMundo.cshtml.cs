using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IntroduccionRazor_ASPNET.Pages
{
    public class HolaMundoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
